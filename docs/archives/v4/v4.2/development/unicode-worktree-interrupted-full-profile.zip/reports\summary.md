# CI Report - profile `full` - FAIL

**Platform**: windows (Windows 11)
**Python**: 3.12.10
**Duration**: 2735.1s

| Result | Count |
|---|---|
| Passed | 45 |
| Failed | 16 |
| Skipped | 0 |
| Advisory failures | 0 |

**Change scope**: no --base supplied; running every group

## Groups

| Group | Status | Commands | Duration |
|---|---|---|---|
| catalog-parse | PASS | 4 command(s) | 0.6s |
| hygiene | PASS | 7 command(s) | 118.8s |
| interpreters | PASS | 2 command(s) | 2.3s |
| catalog | PASS | 6 command(s) | 5.4s |
| security | PASS | 3 command(s) | 5.0s |
| workflows | PASS | 2 command(s) | 0.5s |
| claude-plugin | PASS | 1 command(s) | 0.7s |
| platform-contracts | PASS | 7 command(s) | 17.0s |
| docs | PASS | 8 command(s) | 1.4s |
| version | PASS | 1 command(s) | 0.1s |
| tests | FAIL | 13 command(s) | 2583.2s |
| extension-tests | FAIL | 7 command(s) | 0.0s |

## Failures

### FAIL `tests` / repo-tests-integrations-platform-b

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/integrations/test_copilot_hermes_native.py
```

### FAIL `tests` / repo-tests-integrations-adapter-contracts

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/integrations/test_base_writeresult.py
```

### FAIL `tests` / repo-tests-integrations-repository-contracts

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/integrations/test_harness_audit.py
```

### FAIL `tests` / repo-tests-integrations-install

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/integrations/test_hooks_supported_gate.py
```

### FAIL `tests` / repo-tests-integrations-lifecycle

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/integrations/test_lifecycle.py
```

### FAIL `tests` / repo-tests-plans

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/plans
```

### FAIL `tests` / repo-tests-ci

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/ci
```

### FAIL `tests` / repo-tests-guides

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/guides
```

### FAIL `tests` / repo-tests-governance

Exit code: `4`. exit 4

```text

no tests ran in 0.00s
ERROR: file or directory not found: tests/validators
```

### MISSING `extension-tests` / skill-server

Exit code: `None`. working directory not found: extensions/nexus-skill-server

```text
(no output captured)
```

### MISSING `extension-tests` / code-search

Exit code: `None`. working directory not found: extensions/nexus-code-search

```text
(no output captured)
```

### MISSING `extension-tests` / web-fetch

Exit code: `None`. working directory not found: extensions/nexus-web-fetch

```text
(no output captured)
```

### MISSING `extension-tests` / skill-scanner

Exit code: `None`. working directory not found: extensions/nexus-skill-scanner

```text
(no output captured)
```

### MISSING `extension-tests` / context-compressor

Exit code: `None`. working directory not found: extensions/nexus-context-compressor

```text
(no output captured)
```

### MISSING `extension-tests` / memory

Exit code: `None`. working directory not found: extensions/nexus-memory

```text
(no output captured)
```

### MISSING `extension-tests` / compression-accuracy-gate

Exit code: `None`. working directory not found: extensions/nexus-context-compressor

```text
(no output captured)
```

## Artifacts

- `reports/summary.md`
- `reports/summary.json`
- `reports/junit/<group>.xml`
- `reports/metadata/environment.json`
