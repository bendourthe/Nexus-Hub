#!/usr/bin/env python3
"""Install and verify portable user-attribution Git hooks without rewriting history."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

HOOKS = [
    "applypatch-msg",
    "pre-applypatch",
    "post-applypatch",
    "pre-commit",
    "pre-merge-commit",
    "prepare-commit-msg",
    "commit-msg",
    "post-commit",
    "pre-rebase",
    "post-checkout",
    "post-merge",
    "pre-push",
    "pre-receive",
    "update",
    "proc-receive",
    "post-receive",
    "post-update",
    "reference-transaction",
    "push-to-checkout",
    "pre-auto-gc",
    "post-rewrite",
    "sendemail-validate",
    "fsmonitor-watchman",
    "p4-changelist",
    "p4-prepare-changelist",
    "p4-post-changelist",
    "p4-pre-submit",
    "post-index-change",
]
AGENT = re.compile(
    r"(?:^|[^a-z0-9])(?:claude|anthropic|codex|openai|cursor(?:agent)?|"
    r"copilot|gemini|antigravity|aider|windsurf|devin|dependabot|renovate|"
    r"chatgpt|gpt|deepseek|qwen|kimi|opencode|openclaw|hermes|"
    r"github-actions|bot)(?:$|[^a-z0-9])|\[bot\]",
    re.IGNORECASE,
)
TRAILER = re.compile(
    r"^\s*(?:co-authored-by|made-with|generated-by|ai-generated|claude-session)\s*:",
    re.IGNORECASE | re.MULTILINE,
)


class GuardError(Exception):
    """An attribution operation could not be verified."""


def git(*args: str, ok: tuple[int, ...] = (0,), input: bytes | None = None) -> str:
    result = subprocess.run(
        ["git", "--no-replace-objects", *args],
        input=input,
        capture_output=True,
        check=False,
    )
    if result.returncode not in ok:
        raise GuardError(
            result.stderr.decode("utf-8", "replace").strip() or "Git command failed"
        )
    return result.stdout.decode("utf-8", "replace").strip()


def human(name: str, email: str) -> None:
    if not name.strip() or not re.fullmatch(r"[^\s<>@]+@[^\s<>@]+", email):
        raise GuardError(
            "Set your own git user.name and user.email before creating contributions."
        )

    # Product words inside a person's full name or mailbox are not evidence
    # of agent authorship (for example Claude Martin or claude.martin).
    def agent_label(value: str) -> bool:
        label = re.sub(
            r"(?:[-_ ]*(?:code|agent|bot|assistant|cli|ide))+$",
            "",
            value.strip(),
            flags=re.IGNORECASE,
        )
        return bool(AGENT.fullmatch(value.strip()) or AGENT.fullmatch(label)) or (
            label.casefold() == "ai"
        )

    mailbox, _, domain = email.casefold().partition("@")
    vendor_bot = mailbox in {"noreply", "no-reply", "bot", "agent"} and domain in {
        "anthropic.com",
        "claude.ai",
        "openai.com",
        "chatgpt.com",
        "cursor.com",
        "cursor.sh",
        "github.com",
    }
    if (
        any(c in name + email for c in "\r\n\x00<>")
        or "[bot]" in (name + email).casefold()
        or agent_label(name)
        or agent_label(mailbox.rsplit("+", 1)[-1])
        or vendor_bot
    ):
        raise GuardError(
            "Agent/bot identities are not permitted; configure your own Git identity."
        )


def identity() -> tuple[str, str]:
    name = git("config", "--get", "user.name", ok=(0, 1))
    email = git("config", "--get", "user.email", ok=(0, 1))
    human(name, email)
    return name, email


def parsed_ident(value: str) -> tuple[str, str]:
    match = re.fullmatch(r"(.*?) <([^<>]+)> \d+ [+-]\d{4}", value)
    if not match:
        raise GuardError("Cannot verify Git identity metadata.")
    return match[1], match[2]


def pending() -> None:
    expected = identity()
    committer = parsed_ident(git("var", "GIT_COMMITTER_IDENT"))
    author = parsed_ident(git("var", "GIT_AUTHOR_IDENT"))
    human(*author)
    if committer != expected:
        raise GuardError(
            "Committer differs from your configured Git identity; remove identity overrides."
        )
    # Replaying a human's existing commit preserves its author. New work and
    # ordinary amend operations must use the configured user as author.
    replay = any(
        Path(git("rev-parse", "--git-path", name)).exists()
        for name in ("CHERRY_PICK_HEAD", "rebase-merge", "rebase-apply")
    )
    if author != expected and not replay:
        raise GuardError("Author differs from your configured Git identity.")


def message(value: str) -> None:
    if TRAILER.search(value):
        raise GuardError(
            "Remove attribution trailers (including Co-Authored-By and Made-With)."
        )
    for line in value.splitlines():
        if re.match(
            r"^\s*(?:[^\w\s]+\s*)?(?:generated|made|authored|written)\s+(?:by|with)\b",
            line,
            re.IGNORECASE,
        ) and (AGENT.search(line) or re.search(r"\bAI\b", line, re.IGNORECASE)):
            raise GuardError("Remove the agent-generated attribution footer.")


def scan_push(payload: bytes, remote_url: str) -> None:
    identity()
    remote_commits: list[str] | None = None
    for line in payload.decode("utf-8", "strict").splitlines():
        fields = line.split()
        if len(fields) != 4:
            raise GuardError("Cannot verify malformed pre-push update.")
        _local_ref, new, remote_ref, old = fields
        if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", new) or not re.fullmatch(
            r"[0-9a-f]{40}|[0-9a-f]{64}", old
        ):
            raise GuardError("Cannot verify push object IDs.")
        if not new.strip("0"):
            continue
        kind = git("cat-file", "-t", new)
        if remote_ref.startswith("refs/tags/") and kind == "tag":
            raw = git("cat-file", "tag", new)
            header, _, body = raw.partition("\n\n")
            tagger = next(
                (x[7:] for x in header.splitlines() if x.startswith("tagger ")), ""
            )
            if parsed_ident(tagger) != identity():
                raise GuardError(
                    "Outgoing tag was not created by your configured Git identity."
                )
            message(body)
        # A tag to a tree/blob has no commits; its annotated metadata was checked.
        commit = subprocess.run(
            ["git", "rev-parse", "--verify", new + "^{commit}"],
            capture_output=True,
            check=False,
        )
        if commit.returncode:
            if remote_ref.startswith("refs/tags/"):
                continue
            raise GuardError("Outgoing branch does not resolve to a commit.")
        revs = [new]
        if old.strip("0"):
            git("cat-file", "-e", old)  # missing remote baseline must not silently pass
            revs.append("^" + old)
        else:
            # A new ref has no old-object baseline. Exclude only commits
            # advertised by this push destination, never refs from other remotes
            # or stale local tracking refs.
            if remote_commits is None:
                remote_commits = []
                seen_objects: set[str] = set()
                for line in git("ls-remote", "--refs", remote_url).splitlines():
                    fields = line.split("\t")
                    if len(fields) != 2 or not re.fullmatch(
                        r"[0-9a-f]{40}|[0-9a-f]{64}", fields[0]
                    ):
                        raise GuardError("Cannot verify push destination refs.")
                    if fields[0] in seen_objects:
                        continue
                    seen_objects.add(fields[0])
                    resolved = git(
                        "rev-parse", "--verify", fields[0] + "^{commit}", ok=(0, 1, 128)
                    )
                    if resolved:
                        remote_commits.append(resolved)
            revs.extend("^" + commit for commit in remote_commits)
        records = git(
            "log",
            "--stdin",
            "--format=%an%x00%ae%x00%cn%x00%ce%x00%B%x00",
            input=("\n".join(revs) + "\n").encode("ascii"),
        ).split("\x00")
        for index in range(0, len(records) - 1, 5):
            record = records[index : index + 5]
            if len(record) != 5:
                raise GuardError("Cannot parse outgoing commit metadata.")
            an, ae, cn, ce, body = record
            human(an.lstrip("\n"), ae)
            # GitHub records its service as committer for human-authored web
            # operations. This does not make it an author or an AI contributor.
            if (cn, ce) != ("GitHub", "noreply@github.com"):
                human(cn, ce)
            message(body)


SPECIAL_HOOKS = {"push-to-checkout", "proc-receive", "fsmonitor-watchman"}


def original_directory(
    fallback: str | None, seen: set[Path] | None = None
) -> Path | None:
    if fallback:
        directory = Path(os.path.expanduser(fallback)).resolve()
        state_path = directory / "state.json"
        if state_path.is_file():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            if state.get("owner") == "nexus-hub-attribution":
                seen = set() if seen is None else seen
                if directory in seen:
                    raise GuardError("Recursive hook chain detected.")
                seen.add(directory)
                return original_directory(state["fallback"], seen)
        return directory
    # init can invoke a hook before rev-parse considers the repository valid.
    common = os.environ.get("GIT_COMMON_DIR") or os.environ.get("GIT_DIR")
    if common:
        commondir = Path(common) / "commondir"
        if commondir.is_file():
            common = str(Path(common) / commondir.read_text().strip())
    else:
        common = git("rev-parse", "--git-common-dir", ok=(0, 128))
    return Path(common) / "hooks" if common else None


def needed_hooks(state: dict) -> list[str]:
    directory = original_directory(state["fallback"])
    return [
        hook
        for hook in HOOKS
        if hook not in SPECIAL_HOOKS
        or (
            directory is not None
            and (directory / hook).is_file()
            and os.access(directory / hook, os.X_OK)
        )
    ]


def check_coverage(root: Path, state: dict) -> None:
    for hook in needed_hooks(state):
        if not (root / hook).is_file():
            raise GuardError(
                f"Existing {hook} needs workspace hook integration. Run nexus-hub attribution install --workspace."
            )


def root_for(scope: str) -> Path:
    if scope == "global":
        return (
            Path(os.environ.get("NEXUS_HUB_HOME", str(Path.home() / ".nexus-hub")))
            / "git-hooks"
        )
    return (
        Path(
            git(
                "rev-parse",
                "--path-format=absolute",
                "--git-dir" if scope == "worktree" else "--git-common-dir",
            )
        )
        / "nexus-attribution-hooks"
    )


def wrapper(script: Path, root: Path, hook: str, python: str | None = None) -> str:
    return (
        "#!/bin/sh\nexec "
        + " ".join(
            shlex.quote(x)
            for x in (
                python or Path(sys.executable).as_posix(),
                script.as_posix(),
                "hook",
                "--hooks-root",
                root.as_posix(),
                hook,
            )
        )
        + ' "$@"\n'
    )


def install(scope: str) -> int:
    if scope == "local":
        probe = subprocess.run(
            ["git", "rev-parse", "--git-dir"], capture_output=True, check=False
        )
        if probe.returncode:
            print(
                "NEEDS SETUP: Workspace is not a Git repository. After git init, run nexus-hub attribution install --workspace."
            )
            return 0
        if git("config", "--bool", "extensions.worktreeConfig", ok=(0, 1)) == "true":
            scope = "worktree"
    root = root_for(scope).resolve()
    state_path = root / "state.json"
    script = Path(__file__).resolve()
    durable_script = root / "guard.py"
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        current = git("config", "--" + scope, "--get", "core.hooksPath", ok=(0, 1))
        if current not in (root.as_posix(), state["previous"] or ""):
            raise GuardError(
                "Hook configuration changed since installation; uninstall the old guard before reinstalling."
            )
    else:
        if root.exists() and any(root.iterdir()):
            raise GuardError("Refusing to replace an unrecognized hooks directory.")
        previous = git("config", "--" + scope, "--get", "core.hooksPath", ok=(0, 1))
        fallback = previous
        if not fallback:
            fallback = git(
                "config",
                "--system"
                if scope == "global"
                else ("--local" if scope == "worktree" else "--global"),
                "--get",
                "core.hooksPath",
                ok=(0, 1),
            )
        if not fallback and scope != "global":
            fallback = git("config", "--get", "core.hooksPath", ok=(0, 1))
        state = {
            "owner": "nexus-hub-attribution",
            "scope": scope,
            "previous": previous or None,
            "fallback": fallback or None,
        }
    root.mkdir(parents=True, exist_ok=True)
    if durable_script.is_symlink():
        raise GuardError("Refusing to replace a symlinked attribution guard.")
    selected = needed_hooks(state)
    for hook in set(state.get("hooks", [])) - set(selected):
        path = root / hook
        recognized = {wrapper(durable_script, root, hook, state.get("python"))}
        if "script_sha256" not in state:
            recognized.add(wrapper(script, root, hook, state.get("python")))
        if path.is_file() and path.read_text(encoding="utf-8") in recognized:
            path.unlink()
        elif path.exists():
            raise GuardError(
                f"Obsolete hook was modified: {hook}. Restore it before reinstalling."
            )
    state["hooks"] = selected
    state["python"] = Path(sys.executable).as_posix()
    script_bytes = script.read_bytes()
    durable_script.write_bytes(script_bytes)
    state["script_sha256"] = hashlib.sha256(script_bytes).hexdigest()
    for hook in selected:
        path = root / hook
        path.write_text(
            wrapper(durable_script, root, hook), encoding="utf-8", newline="\n"
        )
        path.chmod(0o755)
    state_path.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    git("config", "--" + scope, "core.hooksPath", root.as_posix())
    if (
        scope != "global"
        and Path(git("config", "--path", "--get", "core.hooksPath")).resolve() != root
    ):
        raise GuardError(
            "A higher-precedence Git configuration overrides activation. Remove that override and reinstall."
        )
    print(f"Attribution hooks installed ({scope}). Existing hooks are chained.")
    try:
        identity()
    except GuardError as exc:
        print(
            f"NEEDS SETUP: {exc} Hooks block contributions until identity is configured."
        )
    return 0


def check() -> int:
    expected = identity()
    pending()
    active = git("config", "--path", "--get", "core.hooksPath", ok=(0, 1))
    if not active:
        raise GuardError(
            "No attribution guard active. Run nexus-hub attribution install --workspace."
        )
    root = Path(active).resolve()
    if not (root / "state.json").is_file():
        raise GuardError(
            "Repository overrides the guard. Run nexus-hub attribution install --workspace."
        )
    state = json.loads((root / "state.json").read_text(encoding="utf-8"))
    durable_script = root / "guard.py"
    if (
        not durable_script.is_file()
        or durable_script.is_symlink()
        or hashlib.sha256(durable_script.read_bytes()).hexdigest()
        != state.get("script_sha256")
    ):
        raise GuardError("Attribution guard missing or modified. Reinstall the guard.")
    source = Path(__file__).resolve()
    if (
        source != durable_script
        # Git may check out the same source blob with LF or CRLF in another
        # worktree. The installed copy still has the byte-exact digest above.
        and source.read_bytes().replace(b"\r\n", b"\n")
        != durable_script.read_bytes().replace(b"\r\n", b"\n")
    ):
        raise GuardError("Attribution guard version differs. Reinstall the guard.")
    try:
        interpreter = subprocess.run(
            [state["python"], "-c", "pass"],
            capture_output=True,
            check=False,
            timeout=10,
        )
        if interpreter.returncode:
            raise GuardError("Installed Python is unavailable. Reinstall the guard.")
    except (OSError, subprocess.SubprocessError) as exc:
        raise GuardError(
            "Installed Python is unavailable. Reinstall the guard."
        ) from exc
    check_coverage(root, state)
    for hook in state["hooks"]:
        path = root / hook
        if (
            not path.is_file()
            or path.read_text(encoding="utf-8")
            != wrapper(durable_script, root, hook, state["python"])
            or not os.access(path, os.X_OK)
        ):
            raise GuardError(
                f"Attribution hook missing or modified: {hook}. Reinstall the guard."
            )
    print(
        f"VERIFIED: Git hooks active for {expected[0]} <{expected[1]}>. Direct API writes are outside this guard."
    )
    return 0


def uninstall(scope: str) -> int:
    if (
        scope == "local"
        and git("config", "--bool", "extensions.worktreeConfig", ok=(0, 1)) == "true"
    ):
        scope = "worktree"
    root = root_for(scope).resolve()
    state = json.loads((root / "state.json").read_text(encoding="utf-8"))
    if (
        git("config", "--" + scope, "--get", "core.hooksPath", ok=(0, 1))
        != root.as_posix()
    ):
        raise GuardError(
            "Hook configuration changed; refusing to overwrite it during uninstall."
        )
    if state["previous"] is None:
        git("config", "--" + scope, "--unset-all", "core.hooksPath")
    else:
        git("config", "--" + scope, "core.hooksPath", state["previous"])
    # Keep the inert files as recovery evidence; no recursive deletion of hooks.
    print(
        "Attribution hooks disabled; previous hooksPath restored. Hook files retained."
    )
    return 0


def hook_run(root: Path, hook: str, args: list[str]) -> int:
    state = json.loads((root / "state.json").read_text(encoding="utf-8"))
    payload = (
        sys.stdin.buffer.read()
        if hook
        in (
            "pre-push",
            "pre-receive",
            "post-receive",
            "post-rewrite",
            "reference-transaction",
        )
        else None
    )
    if hook in ("pre-commit", "pre-merge-commit", "prepare-commit-msg", "commit-msg"):
        check_coverage(root, state)
        pending()
    if hook == "commit-msg":
        message(Path(args[0]).read_text(encoding="utf-8", errors="replace"))
    if hook == "pre-push":
        check_coverage(root, state)
        if len(args) < 2:
            raise GuardError("Cannot verify push destination.")
        scan_push(payload or b"", args[1])
    directory = original_directory(state["fallback"])
    previous = directory / hook if directory is not None else None
    if previous is not None and previous.resolve() == (root / hook).resolve():
        raise GuardError("Recursive hook chain detected.")
    if previous is not None and previous.is_file() and os.access(previous, os.X_OK):
        # Git hooks are executable files with a shebang; Git for Windows uses sh.
        command = [str(previous.resolve()), *args]
        if os.name == "nt":
            command = ["sh", "-c", 'exec "$@"', "nexus-attribution", *command]
        result = subprocess.run(command, input=payload, check=False).returncode
        if result:
            return result
    if hook == "commit-msg":
        message(Path(args[0]).read_text(encoding="utf-8", errors="replace"))
    return 0


# --- agent-hook scan ------------------------------------------------------------
#
# `scan` reads a PreToolUse payload on stdin for the attribution-guard .sh and .ps1
# siblings. It blocks (exit 2) AI attribution in trailer or footer position on every
# publishing route: git commit/tag messages, gh pr/issue/release bodies (including
# --body-file and --fill), gh api body fields, and GitHub MCP tools. Text that names a
# tool as a subject ("generated with pandoc") passes. A body that cannot be read safely
# warns and passes; a device or FIFO is never opened.

SCAN_HOOK = "attribution-guard"
VENDOR = (r"(?:claude(?:\s+code)?|codex|copilot|cursor|gemini|devin|kimi|qwen|anthropic|openai|"
          r"chatgpt|aider|windsurf|antigravity)")
MODEL_WORDS = (r"(?:\s+(?:opus|sonnet|haiku|pro|flash|mini|nano|turbo|max|ultra|preview|code|cli|agent|"
               r"v?\d[\w.]*))*")
AGENT_NAME = re.compile(r"^" + VENDOR + MODEL_WORDS + r"$", re.IGNORECASE)
FOOTER = re.compile(
    r"^\s*(?:[^\w\s]+\s*)?(?:generated|made|created|written|authored)\s+(?:with|by|using)\s+"
    r"(?:\[\s*)?" + VENDOR + MODEL_WORDS + r"(?:\s*\])?(?:\s*(?:\([^)]*\)|\[[^\]]*\]))?"
    r"(?:\s+by\s+" + VENDOR + r")?"
    # Once a vendor name matched, a clause of any length after a separator is still a
    # footer, as on the commit-msg route (`message`); a tool subject such as pandoc never
    # reaches this point because it is not a VENDOR.
    r"(?:\s*[-:,|]\s*(?:https?://\S*|\S.*?))?[\s.!]*$",
    re.IGNORECASE,
)
MARKUP = re.compile(r"<[^>]+>|[_*`~]")
BADGE = re.compile(r"\U0001F916|:robot(?:_face)?:", re.IGNORECASE)
VENDOR_NOREPLY = re.compile(
    r"@(?:users\.noreply\.)?(?:anthropic\.com|claude\.ai|openai\.com|chatgpt\.com|cursor\.com|cursor\.sh)\b",
    re.IGNORECASE,
)
FOOTER_WINDOW = 6
BODY_FILE_CAP = 1024 * 1024
BODY_FIELDS = {"body", "message", "commit_message", "notes", "description", "title"}
MCP_PREFIXES = ("mcp__github__", "mcp__plugin_github_github__")


def attribution_pattern(text: str) -> tuple[str, str] | None:
    """(pattern id, offending line) for the first attribution in trailer or footer position."""
    lines = text.splitlines()
    for line in lines:
        if TRAILER.match(line):
            key, _, value = line.partition(":")
            key = key.strip().casefold()
            if key == "co-authored-by":
                if _agent_coauthor(value):
                    return f"trailer:{key}", line
            elif key in ("ai-generated", "claude-session") or AGENT.search(value) or VENDOR_NOREPLY.search(value):
                return f"trailer:{key}", line
    tail = [line for line in lines if line.strip()][-FOOTER_WINDOW:]
    for line in tail:
        if FOOTER.match(MARKUP.sub("", line)):
            return "footer:generated-with-agent", line
        if BADGE.search(line):
            return "badge:robot", line
    return None


def _agent_coauthor(value: str) -> bool:
    """A co-author trailer names an agent: the same identity rule the Git hooks apply to authors."""
    match = re.match(r"\s*(.*?)\s*<([^>]*)>", value)
    name, email = (match.group(1), match.group(2)) if match else (value.strip(), "someone@example.com")
    if VENDOR_NOREPLY.search("@" + email.partition("@")[2]) or AGENT_NAME.match(name.strip()):
        return True
    try:
        human(name or "unknown", email if "@" in email else "someone@example.com")
    except GuardError as exc:
        return "Agent/bot" in str(exc)
    return False


def _snippet(text: str) -> str:
    return "".join(ch if ch.isprintable() and ord(ch) < 128 else "?" for ch in text)[:80]


def _read_body_file(path: str, cwd: Path) -> tuple[str | None, str | None]:
    """(text, None) for a safe regular file; (None, reason) otherwise."""
    if path == "-":
        return None, "body read from stdin"
    if "$" in path:
        return None, "body file named by an unexpanded variable"
    target = Path(path) if Path(path).is_absolute() else cwd / path
    try:
        info = os.lstat(target)
    except OSError:
        return None, "body file is missing"
    import stat as stat_mod

    if not stat_mod.S_ISREG(info.st_mode):
        return None, "body file is not a regular file"
    if info.st_size > BODY_FILE_CAP:
        return None, "body file is over 1 MB"
    try:
        body = target.read_bytes()
        if b"\x00" in body:
            return None, "body file contains NUL bytes"
        return body.decode("utf-8", errors="replace"), None
    except OSError:
        return None, "body file is unreadable"


def _words(command: str) -> list[list[str]]:
    lexer = shlex.shlex(command.replace("\\", "/"), posix=True, punctuation_chars=";&|")
    lexer.whitespace_split = True
    lexer.commenters = ""
    try:
        tokens = list(lexer)
    except ValueError:
        tokens = command.split()
    segments: list[list[str]] = [[]]
    for token in tokens:
        if token in {";", "&&", "||", "|", "&"}:
            segments.append([])
        else:
            segments[-1].append(token)
    return [s for s in segments if s]


def _option_values(args: list[str], names: set[str]) -> list[str]:
    values: list[str] = []
    for index, arg in enumerate(args):
        for name in names:
            if arg == name and index + 1 < len(args):
                values.append(args[index + 1])
            elif name.startswith("--") and arg.startswith(name + "="):
                values.append(arg.split("=", 1)[1])
            elif not name.startswith("--") and len(name) == 2 and arg.startswith(name) and len(arg) > 2:
                values.append(arg[2:])
    return values


def _fill_messages(args: list[str], cwd: Path) -> tuple[str | None, str | None]:
    base = (_option_values(args, {"--base", "-B"}) or ["origin/HEAD"])[0]
    try:
        result = subprocess.run(
            ["git", "log", "-n", "200", "--format=%B", f"{base}..HEAD"],
            cwd=cwd, capture_output=True, timeout=3, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None, "could not read the commit range for --fill"
    if result.returncode:
        return None, "could not read the commit range for --fill"
    return result.stdout.decode("utf-8", "replace"), None


def _route_bodies(words: list[str], cwd: Path) -> tuple[str, list[str], list[str]] | None:
    """(route, bodies, unverifiable reasons) for a publishing command, else None."""
    while words and (re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", words[0])
                     or words[0] in ("env", "sudo", "command", "exec", "nohup", "time", "builtin")):
        words = words[1:]
    if not words:
        return None
    head = Path(words[0]).name.lower().removesuffix(".exe")
    bodies: list[str] = []
    reasons: list[str] = []

    def files(values: list[str]) -> None:
        for value in values:
            text, reason = _read_body_file(value, cwd)
            if text is not None:
                bodies.append(text)
            else:
                reasons.append(reason or "body cannot be read")

    if head == "git":
        rest = words[1:]
        while rest and rest[0].startswith("-"):
            takes_value = rest[0] in ("-C", "-c", "--git-dir", "--work-tree", "--namespace", "--exec-path")
            rest = rest[2:] if takes_value else rest[1:]
        if not rest or rest[0] not in ("commit", "tag", "merge"):
            return None
        args = rest[1:]
        bodies += _option_values(args, {"-m", "--message"})
        bodies += [re.sub(r"^([\w-]+)\s*=", r"\1:", value) for value in _option_values(args, {"--trailer"})]
        files(_option_values(args, {"-F", "--file"}))
        return f"git {rest[0]}", bodies, reasons
    if head != "gh" or len(words) < 2:
        return None
    if words[1] == "api":
        args = words[2:]
        files(_option_values(args, {"--input"}))
        for field in _option_values(args, {"-f", "-F", "--field", "--raw-field"}):
            key, _, value = field.partition("=")
            if key.strip().casefold() in BODY_FIELDS:
                if value.startswith("@"):
                    files([value[1:]])
                else:
                    bodies.append(value)
        return "gh api", bodies, reasons
    if len(words) < 3 or words[1] not in ("pr", "issue", "release") or words[2] not in (
        "create", "edit", "comment", "review", "merge"
    ):
        return None
    args = words[3:]
    bodies += _option_values(args, {"--body", "-b", "--notes", "-n", "--title", "-t", "--subject"})
    files(_option_values(args, {"--body-file", "-F", "--notes-file"}))
    if any(a in ("--fill", "--fill-first", "--fill-verbose", "-f") for a in args) and words[1] == "pr":
        text, reason = _fill_messages(args, cwd)
        if text is not None:
            bodies.append(text)
        else:
            reasons.append(reason or "--fill range unreadable")
    return f"gh {words[1]} {words[2]}", bodies, reasons


HEREDOC = re.compile(r"<<-?\s*(['\"]?)([^\s'\"]+)\1[^\n]*\n(.*?)\n\s*\2\s*(?:\n|$)", re.DOTALL)


def _mcp_bodies(value: object) -> list[str]:
    if isinstance(value, dict):
        found: list[str] = []
        for key, item in value.items():
            if isinstance(item, str) and key.casefold() in BODY_FIELDS:
                found.append(item)
            elif isinstance(item, (dict, list)):
                found += _mcp_bodies(item)
        return found
    if isinstance(value, list):
        return [text for item in value for text in _mcp_bodies(item)]
    return []


def _scan_block(route: str, pattern: str, line: str) -> int:
    print(f"[{SCAN_HOOK}] BLOCKED: {route} carries AI attribution (pattern {pattern}).", file=sys.stderr)
    print(f"Line: {_snippet(line.strip())}", file=sys.stderr)
    print("Remove the co-author trailer, generated-with footer, or badge; your own identity is the "
          "only author. Naming a tool as the subject of a sentence is fine.", file=sys.stderr)
    return 2


def scan(payload: dict) -> int:
    tool = str(payload.get("tool_name") or "")
    tool_input = payload.get("tool_input") or {}
    cwd = Path(payload.get("cwd") or os.getcwd())
    if tool.startswith(MCP_PREFIXES):
        for text in _mcp_bodies(tool_input):
            found = attribution_pattern(text)
            if found:
                return _scan_block(tool, *found)
        return 0
    if tool in ("Write", "Edit", "MultiEdit"):
        path = str(tool_input.get("file_path") or "").replace("\\", "/")
        if path.rsplit("/", 1)[-1] == "CHANGELOG.md" or "/docs/" in f"/{path}":
            text = str(tool_input.get("content") or tool_input.get("new_string") or "")
            found = attribution_pattern(text)
            if found:
                print(f"[{SCAN_HOOK}] WARNING: {_snippet(path)} would carry AI attribution "
                      f"(pattern {found[0]}); remove it unless the text describes the pattern.", file=sys.stderr)
        return 0
    if tool not in ("Bash", "PowerShell"):
        return 0
    command = str(tool_input.get("command") or "")
    heredocs = [m.group(3) for m in HEREDOC.finditer(command)]
    unverified: list[str] = []
    for words in _words(HEREDOC.sub("\n", command)):
        found = _route_bodies(words, cwd)
        if found is None:
            continue
        route, bodies, reasons = found
        for text in bodies + heredocs:
            found = attribution_pattern(text)
            if found:
                return _scan_block(route, *found)
        if not heredocs:
            unverified += [f"{route}: {reason}" for reason in reasons]
    for reason in dict.fromkeys(unverified):
        print(f"[{SCAN_HOOK}] WARNING: cannot verify body ({reason}); check it for AI attribution "
              "before publishing.", file=sys.stderr)
    return 0


def cmd_scan() -> int:
    try:
        # A launcher may add a byte-order mark before or after the payload; it must never
        # make the JSON unparseable, which would silently allow the tool call.
        payload = json.loads(sys.stdin.read().replace("\ufeff", "").strip() or "null")
    except ValueError:
        return 0
    if not isinstance(payload, dict):
        return 0
    try:
        return scan(payload)
    except Exception as exc:  # noqa: BLE001 - the hook must degrade to a warning, never crash
        print(f"[{SCAN_HOOK}] WARNING: cannot verify body ({type(exc).__name__}).", file=sys.stderr)
        return 0


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if argv[:1] == ["scan"]:
        return cmd_scan()
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("install", "uninstall"):
        child = sub.add_parser(name)
        child.add_argument(
            "--workspace",
            action="store_true",
            help="Wrap this repository's hooks instead of global hooks.",
        )
    sub.add_parser("check")
    sub.add_parser(
        "context", help="Emit installed attribution rules for Cursor sessionStart."
    )
    tag = sub.add_parser(
        "tag", help="Create an annotated tag using verified user identity."
    )
    tag.add_argument("name")
    tag.add_argument("-m", "--message", required=True)
    tag.add_argument("--target", default="HEAD")
    hook = sub.add_parser("hook")
    hook.add_argument("--hooks-root", type=Path, required=True)
    hook.add_argument("name", choices=HOOKS)
    hook.add_argument("args", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    try:
        if args.command == "install":
            return install("local" if args.workspace else "global")
        if args.command == "uninstall":
            return uninstall("local" if args.workspace else "global")
        if args.command == "check":
            return check()
        if args.command == "context":
            guide = (
                Path(__file__).resolve().parent.parent
                / "style-guides/git-attribution.md"
            )
            print(json.dumps({"additional_context": guide.read_text(encoding="utf-8")}))
            return 0
        if args.command == "tag":
            check()
            message(args.message)
            git("tag", "-a", "-m", args.message, "--", args.name, args.target)
            return 0
        return hook_run(args.hooks_root, args.name, args.args)
    except (GuardError, OSError, ValueError, KeyError, IndexError) as exc:
        print(f"Attribution BLOCKED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
