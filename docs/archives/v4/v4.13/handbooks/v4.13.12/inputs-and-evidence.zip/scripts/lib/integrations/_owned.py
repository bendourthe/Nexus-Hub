"""Ownership-aware file writes shared by the native-surface adapters.

``IntegrationBase._copy_file`` is ownership-blind: any existing destination is
"kept" unless the whole install runs with ``--overwrite``. That is the right
default for a bulk tree copy, but it cannot express the contract the v3.15.8
native surfaces need, where a file Nexus-Hub generated must be repaired when it
drifts while a file the user wrote must be left alone. The distinguishing
information is the install manifest, so the write consults it.

This primitive was introduced for Codex in Phase 5 and is used by Kimi in
Phase 7. It lives here rather than in either platform's module so there is one
implementation of "is this ours?" across every adapter that needs it.
"""

from __future__ import annotations

import os
import stat
import uuid
from pathlib import Path

from .base import long_path
from .result import FileAction


def is_owned(ctx, key: str, path: Path) -> bool:
    """True when the manifest records ``path`` as written by this integration."""
    return str(path) in set(ctx.manifest.files_for(key))


def _spellings(path: Path) -> tuple:
    """``path`` plus its extended-length form when that differs (AR-11).

    A plain ``lstat`` past Windows MAX_PATH fails and pathlib reports that as
    "not a link", so a link check that asked only the plain spelling would let a
    deep redirected entry through. Asking both refuses more, never less.
    """
    if not isinstance(path, Path):
        return (path,)
    io_path = long_path(path)
    return (path,) if io_path == path else (path, io_path)


def _is_junction_at(path: Path) -> bool:
    checker = getattr(path, "is_junction", None)
    try:
        if checker is not None and checker():
            return True
        reparse_tag = getattr(path.lstat(), "st_reparse_tag", None)
    except OSError:
        return False
    mount_point_tag = getattr(stat, "IO_REPARSE_TAG_MOUNT_POINT", None)
    return mount_point_tag is not None and reparse_tag == mount_point_tag


def _is_junction(path: Path) -> bool:
    return any(_is_junction_at(spelling) for spelling in _spellings(path))


def _is_symlink(path: Path) -> bool:
    return any(spelling.is_symlink() for spelling in _spellings(path))


def _is_link_like(path: Path) -> bool:
    """Return whether replacing ``path`` must not reuse its current inode."""
    if _is_symlink(path) or _is_junction(path):
        return True
    for spelling in reversed(_spellings(path)):
        try:
            return spelling.lstat().st_nlink > 1
        except OSError:
            continue
    return False


def _relative_within(destination: Path, managed_root: Path) -> Path | None:
    """Return ``destination`` relative to ``managed_root``, or None if outside it.

    Containment is a question about locations, not spellings. Windows 8.3 short
    names and POSIX symlinked parents denote the same directory as their long
    forms while comparing unequal, and ``os.path.abspath`` normalizes neither.
    Comparing only the ``abspath`` spellings therefore turned every write under
    such a root into a silent refusal reported as "kept", with nothing on disk
    and no error raised, so an installer reported success and delivered nothing
    (v4.3.0 Phase 5 regression).

    The canonical comparison is a fallback, never the primary test: the caller
    must walk the ORIGINAL spelling to see symlinked ancestors at all, because
    ``realpath`` resolves exactly the entries that guard exists to detect.
    """
    try:
        return destination.relative_to(managed_root)
    except ValueError:
        pass
    try:
        canonical_root = Path(os.path.realpath(managed_root))
        canonical_destination = Path(os.path.realpath(destination))
        return canonical_destination.relative_to(canonical_root)
    except (OSError, ValueError):
        return None


def _link_like_managed_ancestor(
    ctx, dst: Path, managed_root: Path | None = None
) -> Path | None:
    """Return the first redirecting ancestor inside the per-write managed root."""
    explicit_root = managed_root is not None
    managed_root = Path(os.path.abspath(managed_root or ctx.target_root))
    destination = Path(os.path.abspath(dst))
    relative = _relative_within(destination, managed_root)
    if relative is None:
        # A caller without a per-write root can legitimately write outside
        # target_root. Explicit roots are rejected before this helper is called.
        return None

    if explicit_root and _redirects(managed_root):
        return managed_root
    current = managed_root
    for part in relative.parts[:-1]:
        current /= part
        if _redirects(current):
            return current
    return None


def _redirects(path: Path) -> bool:
    """True when ``path`` is a symlink or junction, checked past MAX_PATH too."""
    return _is_symlink(path) or _is_junction(path)


def refuse_managed_redirect(
    ctx, key: str, dst: Path, managed_root: Path | None = None
) -> FileAction | None:
    """Return a visible refusal before any write through a managed directory link."""
    link_like_ancestor = _link_like_managed_ancestor(ctx, dst, managed_root)
    if link_like_ancestor is None:
        return None
    reason = f"refuse-link-like-ancestor ({link_like_ancestor})"
    ctx.manifest.log(key, f"{reason}: {dst}")
    return FileAction(path=str(dst), action="kept", reason=reason)


#: Mode for the staging file. Deliberately owner-only rather than the previous
#: 0o666, which is `0o666 & ~umask` in practice: on a host with umask 000 that
#: is a WORLD-WRITABLE file sitting in the user's config directory for the
#: window between creation and the rename, in installed code that runs on a
#: user's machine (CodeQL `py/overly-permissive-file`, recorded as v4.8 WN-K).
#: The staging file's mode is a private implementation detail, so the safe
#: default costs nothing; the mode the USER ends up with is decided below.
_STAGING_MODE = 0o600


def _atomic_replace_bytes(dst: Path, content: bytes) -> None:
    """Replace one directory entry without ever opening ``dst`` for writing.

    Two properties, in this order. The staging file is created owner-only, so no
    umask can widen it. Then, when ``dst`` already exists, its mode is copied
    onto the staging file before the rename, because ``os.replace`` carries the
    SOURCE's mode: without that step a refresh would silently rewrite the
    permissions of a file the user may have chmod'ed deliberately.

    This mirrors the sibling implementation in
    ``scripts/lib/installer/instruction_merge.py``, which already stats the
    destination and reapplies its mode. The convention is the repository's own;
    this function was simply the copy that had not adopted it.
    """
    temporary = dst.with_name(f".{dst.name}.{uuid.uuid4().hex}.tmp")
    descriptor = os.open(
        temporary,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL,
        _STAGING_MODE,
    )
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
        try:
            existing_mode = stat.S_IMODE(dst.stat().st_mode)
        except OSError:
            # No destination yet (the common first-install path), or its mode is
            # unreadable. A new file keeps the owner-only staging mode, which is
            # the conservative choice for a file this tool created.
            existing_mode = None
        if existing_mode is not None:
            os.chmod(temporary, existing_mode)
        os.replace(temporary, dst)
    finally:
        temporary.unlink(missing_ok=True)


def write_owned_file(
    ctx, key: str, dst: Path, content: bytes, *, managed_root: Path | None = None
) -> FileAction:
    """Write a generated file, never clobbering one Nexus-Hub does not own.

    An existing destination that the manifest does not record as ours is a
    user-authored file, so it is kept (unless ``--overwrite`` is explicit).
    A destination we do own is refreshed on byte-difference, which is what makes
    an upgrade idempotent and a drifted file repairable. `managed_root` preserves
    the original platform-root spelling so redirected ancestors remain visible.
    """
    if managed_root is not None and _relative_within(
        Path(os.path.abspath(dst)), Path(os.path.abspath(managed_root))
    ) is None:
        reason = f"refuse-outside-managed-root ({managed_root})"
        ctx.manifest.log(key, f"{reason}: {dst}")
        return FileAction(path=str(dst), action="kept", reason=reason)
    refusal = refuse_managed_redirect(ctx, key, dst, managed_root)
    if refusal is not None:
        return refusal

    # File operations use the extended-length form (AR-11): the staging name adds
    # 38 characters, so even a destination under MAX_PATH can fail without it.
    # Ownership, the manifest, and the returned action keep the plain path.
    dst_io = long_path(dst)
    entry_exists = dst_io.exists() or _is_symlink(dst) or _is_junction(dst)
    if entry_exists:
        link_like = _is_link_like(dst)
        if not is_owned(ctx, key, dst) and not ctx.overwrite:
            ctx.manifest.log(key, f"skip-existing (user-authored): {dst}")
            return FileAction(path=str(dst), action="kept")
        if not link_like and dst_io.is_file() and dst_io.read_bytes() == content:
            ctx.manifest.track(key, str(dst))
            return FileAction(path=str(dst), action="unchanged")
        if _is_junction(dst):
            reason = "refuse-managed-junction"
            ctx.manifest.log(key, f"{reason}: {dst}")
            return FileAction(path=str(dst), action="kept", reason=reason)
        if not ctx.dry_run:
            dst_io.parent.mkdir(parents=True, exist_ok=True)
            _atomic_replace_bytes(dst_io, content)
        ctx.manifest.track(key, str(dst))
        return FileAction(path=str(dst), action="updated")
    if not ctx.dry_run:
        dst_io.parent.mkdir(parents=True, exist_ok=True)
        _atomic_replace_bytes(dst_io, content)
    ctx.manifest.track(key, str(dst))
    return FileAction(path=str(dst), action="created")


def remove_dir_if_empty(path: Path, ctx, result) -> None:
    """Drop a directory only when teardown emptied it completely.

    Per-file tracking means removing the files leaves the parent behind, which
    reads as an install that did not fully uninstall. Removal is best-effort on
    purpose: on Windows a file whose handle is still open by another process
    enters a delete-pending state where it no longer appears in a directory
    listing but still blocks ``rmdir`` with ``PermissionError``. A leftover empty
    directory is cosmetic, whereas raising here would abort the rest of the
    teardown and leave real content behind, so the failure is recorded and
    execution continues.
    """
    if not path.is_dir() or any(path.iterdir()):
        return
    if ctx.dry_run:
        result.add(str(path), "removed")
        return
    try:
        path.rmdir()
    except OSError as exc:
        ctx.manifest.log("install", f"keep-dir (not removable): {path} ({exc})")
        result.add(str(path), "kept")
        return
    result.add(str(path), "removed")


__all__ = ["is_owned", "refuse_managed_redirect", "remove_dir_if_empty", "write_owned_file"]
